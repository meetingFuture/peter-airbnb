import reducer from "./reducer";

export default reducer;
